import React, { useState, useEffect } from 'react';
import { Menu, X, MapPin, Clock, Phone, Mail } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="relative min-h-screen">
      {/* Fixed Spline Background */}
      <div className="fixed inset-0 z-0">
        <iframe 
          src="https://my.spline.design/galaxycoffecup-gkzDMuGM61g8YgvBFD0KNay3/"
          className="w-full h-full border-0"
          style={{ minHeight: '100vh' }}
          title="Galaxy Coffee Cup Animation"
        />
      </div>

      {/* Content Overlay */}
      <div className="relative z-10">
        {/* Floating Navigation */}
        <header className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-300 w-full max-w-7xl px-6">
          <div 
            className="glass-effect rounded-full px-6 py-4 flex items-center justify-between mx-auto max-w-6xl"
          >
            {/* Logo on the left */}
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-white tracking-wide" style={{ fontFamily: 'Playfair Display, serif' }}>
                Qahvo
              </h1>
            </div>

            {/* Center Navigation - Desktop */}
            <nav className="hidden lg:flex gap-8">
              <button onClick={() => scrollToSection('hero')} className="nav-link">Home</button>
              <button onClick={() => scrollToSection('about')} className="nav-link">About</button>
              <button onClick={() => scrollToSection('menu')} className="nav-link">Menu</button>
              <button onClick={() => scrollToSection('contact')} className="nav-link">Contact</button>
            </nav>

            {/* Right side - Cart, Search, Mobile Menu */}
            <div className="flex items-center gap-4">
              {/* Search Button */}
              <button className="nav-link p-3 hidden md:block">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"/>
                  <path d="m21 21-4.35-4.35"/>
                </svg>
              </button>

              {/* Cart Button */}
              <button className="nav-link p-3 hidden md:block relative">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="8" cy="21" r="1"/>
                  <circle cx="19" cy="21" r="1"/>
                  <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57L23 6H6"/>
                </svg>
                <span className="absolute -top-1 -right-1 bg-amber-500 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                  0
                </span>
              </button>

              {/* Mobile Menu Button */}
              <button 
                className="lg:hidden nav-link p-3"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? 
                  <X className="w-5 h-5" /> : 
                  <Menu className="w-5 h-5" />
                }
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="lg:hidden mt-4 glass-effect rounded-2xl p-6 mx-6">
              <nav className="flex flex-col gap-2">
                <button onClick={() => scrollToSection('hero')} className="nav-link text-left">Home</button>
                <button onClick={() => scrollToSection('about')} className="nav-link text-left">About</button>
                <button onClick={() => scrollToSection('menu')} className="nav-link text-left">Menu</button>
                <button onClick={() => scrollToSection('contact')} className="nav-link text-left">Contact</button>
                <hr className="border-white/20 my-2" />
                <button className="nav-link text-left flex items-center gap-3">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="m21 21-4.35-4.35"/>
                  </svg>
                  Search
                </button>
                <button className="nav-link text-left flex items-center gap-3">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="8" cy="21" r="1"/>
                    <circle cx="19" cy="21" r="1"/>
                    <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57L23 6H6"/>
                  </svg>
                  Cart (0)
                </button>
              </nav>
            </div>
          )}
        </header>
        {/* Hero Section */}
        <section id="hero" className="min-h-screen flex items-center justify-center text-center px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-6xl md:text-8xl font-bold text-white mb-6 drop-shadow-2xl animate-fade-in-up">
              Artisan Coffee,
              <br />
              <span className="text-amber-500">Crafted Daily</span>
            </h2>
            <p className="text-xl md:text-2xl text-white/80 mb-8 drop-shadow-lg max-w-2xl mx-auto leading-relaxed">
              Welcome to Qahvo, where every cup is crafted with passion and the finest beans from around the world.
            </p>
            <button 
              onClick={() => scrollToSection('menu')}
              className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-5 px-12 rounded-full text-lg cta-button"
            >
              Explore Our Menu
            </button>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-24 px-4">
          <div className="max-w-6xl mx-auto">
            <div className="glass-effect rounded-3xl p-12">
              <div className="text-center mb-8">
                <h3 className="text-4xl md:text-5xl font-bold text-white mb-6 drop-shadow-lg">Our Story</h3>
                <p className="text-lg text-white/80 leading-relaxed max-w-3xl mx-auto drop-shadow-md">
                  Founded in 2018, The Daily Grind has been serving our community with exceptional coffee and warm hospitality. 
                  We source our beans directly from local farmers and roast them fresh daily to ensure every cup delivers 
                  the perfect balance of flavor and aroma that awakens your senses.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Menu Section */}
        <section id="menu" className="py-24 px-4">
          <div className="max-w-6xl mx-auto">
            <h3 className="text-4xl md:text-5xl font-bold text-white text-center mb-12 drop-shadow-lg">Featured Selections</h3>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  name: "Qahvo Signature",
                  description: "Rich, bold espresso made from our house blend of premium beans",
                  price: "$3.50"
                },
                {
                  name: "Vanilla Latte",
                  description: "Smooth espresso with steamed milk and vanilla syrup perfection",
                  price: "$4.75"
                },
                {
                  name: "Fresh Pastries",
                  description: "Daily baked croissants, muffins, and artisanal cookies",
                  price: "$2.50 - $4.00"
                }
              ].map((item, index) => (
                <div 
                  key={index}
                  className="glass-effect rounded-2xl p-8 menu-card"
                >
                  <h4 className="text-2xl font-semibold text-white mb-3 drop-shadow-md">{item.name}</h4>
                  <p className="text-white/80 mb-4 leading-relaxed">{item.description}</p>
                  <p className="text-amber-500 font-bold text-xl">{item.price}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 px-4">
          <div className="max-w-6xl mx-auto">
            <h3 className="text-4xl md:text-5xl font-bold text-white text-center mb-12 drop-shadow-lg">Visit Us Today</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="glass-effect rounded-2xl p-8 contact-card">
                <h4 className="text-2xl font-semibold text-white mb-6 drop-shadow-md">Location & Hours</h4>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1 animate-float" />
                    <div>
                      <p className="text-white font-medium text-lg">123 Main Street</p>
                      <p className="text-white/80">Downtown Coffee District</p>
                      <p className="text-white/80">City, State 12345</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Clock className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-white font-medium text-lg">Operating Hours</p>
                      <p className="text-white/80">Monday - Friday: 6:00 AM - 8:00 PM</p>
                      <p className="text-white/80">Saturday - Sunday: 7:00 AM - 9:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="glass-effect rounded-2xl p-8 contact-card">
                <h4 className="text-2xl font-semibold text-white mb-6 drop-shadow-md">Get In Touch</h4>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <Phone className="w-6 h-6 text-amber-500" />
                    <p className="text-white/80 text-lg">(555) 123-4567</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Mail className="w-6 h-6 text-amber-500" />
                    <p className="text-white/80 text-lg">hello@thedailygrind.com</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-12 px-4">
          <div className="max-w-6xl mx-auto text-center">
            <div className="glass-effect rounded-2xl p-8">
              <h2 className="text-3xl font-bold text-white mb-4 tracking-wide" style={{ fontFamily: 'Playfair Display, serif' }}>
                Qahvo
              </h2>
              <p className="text-white/80 text-lg">© 2025 Qahvo. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;